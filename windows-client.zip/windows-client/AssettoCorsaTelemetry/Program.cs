using System;
using System.Net;
using System.Net.Sockets;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssettoCorsaTelemetry
{
    // Assetto Corsa UDP packet structure
    public struct RTCarInfo
    {
        public char identifier;          // 'a'
        public int size;                // Size of the packet
        public float speed_Kmh;         // Speed in km/h
        public float speed_Mph;         // Speed in mph
        public float speed_Ms;          // Speed in m/s
        public byte isAbsEnabled;       // ABS enabled
        public byte isAbsInAction;      // ABS in action
        public byte isTcInAction;       // TC in action
        public byte isTcEnabled;        // TC enabled
        public byte isInPit;           // In pit
        public byte isEngineLimiterOn; // Engine limiter on
        public float accG_vertical;    // Vertical G-force
        public float accG_horizontal;  // Horizontal G-force
        public float accG_frontal;     // Frontal G-force
        public int lapTime;            // Lap time in milliseconds
        public int lastLap;            // Last lap time in milliseconds
        public int bestLap;            // Best lap time in milliseconds
        public int lapCount;           // Lap count
        public float gas;              // Gas/throttle pedal (0.0-1.0)
        public float brake;            // Brake pedal (0.0-1.0)
        public float clutch;           // Clutch pedal (0.0-1.0)
        public float engineRPM;        // Engine RPM
        public float steer;            // Steering (-1.0 to 1.0)
        public int gear;               // Current gear
        public float cgHeight;         // Center of gravity height
        public float[] wheelAngularSpeed; // Wheel angular speeds [4]
        public float[] slipAngle;      // Slip angles [4]
        public float[] slipAngle_ContactPatch; // Contact patch slip angles [4]
        public float[] slipRatio;      // Slip ratios [4]
        public float[] tyreSlip;       // Tyre slip [4]
        public float[] ndSlip;         // Normalized slip [4]
        public float[] load;           // Load [4]
        public float[] Dy;             // Dy [4]
        public float[] Mz;             // Mz [4]
        public float[] tyreDirtyLevel; // Tyre dirty level [4]
        public float[] camberRAD;      // Camber in radians [4]
        public float[] tyreRadius;     // Tyre radius [4]
        public float[] tyreLoadedRadius; // Tyre loaded radius [4]
        public float[] suspensionHeight; // Suspension height [4]
        public float carPositionNormalized; // Car position normalized
        public float carSlope;         // Car slope
        public float[] carCoordinates; // Car coordinates [3] - X, Y, Z
    }

    // Simplified telemetry point for sending to web app
    public class TelemetryPoint
    {
        public float time { get; set; }
        public float x { get; set; }
        public float z { get; set; }
        public float speed { get; set; }
        public float throttle { get; set; }
        public float brake { get; set; }
        public float steering { get; set; }
        public float gForceX { get; set; }
        public float gForceZ { get; set; }
        public int gear { get; set; }
        public float rpm { get; set; }
    }

    // Lap data structure
    public class LapData
    {
        public string lapTime { get; set; } = "";
        public string car { get; set; } = "Unknown";
        public string track { get; set; } = "Spa-Francorchamps";
        public string conditions { get; set; } = "Dry";
        public List<TelemetryPoint> telemetryPoints { get; set; } = new();
        public SectorTimes sectorTimes { get; set; } = new();
    }

    public class SectorTimes
    {
        public float sector1 { get; set; }
        public float sector2 { get; set; }
        public float sector3 { get; set; }
    }

    class Program
    {
        private static UdpClient? udpClient;
        private static List<TelemetryPoint> currentLapData = new();
        private static int lastLapCount = -1;
        private static string webAppUrl = "http://192.168.4.28:3000"; // Your Mac's IP from terminal output
        
        static async Task Main(string[] args)
        {
            Console.WriteLine("🏁 Trail Break - Assetto Corsa Telemetry Capture");
            Console.WriteLine("============================================");
            Console.WriteLine($"Listening for Assetto Corsa UDP on port 9600...");
            Console.WriteLine($"Web app URL: {webAppUrl}");
            Console.WriteLine("Press Ctrl+C to exit\n");

            try
            {
                udpClient = new UdpClient(9600);
                IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

                while (true)
                {
                    try
                    {
                        // Receive UDP packet from Assetto Corsa
                        byte[] data = udpClient.Receive(ref remoteEndPoint);
                        
                        if (data.Length > 0 && data[0] == (byte)'a')
                        {
                            await ProcessTelemetryData(data);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error receiving data: {ex.Message}");
                        await Task.Delay(1000);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to start UDP listener: {ex.Message}");
                Console.WriteLine("Make sure:");
                Console.WriteLine("1. Assetto Corsa is running");
                Console.WriteLine("2. UDP telemetry is enabled in AC settings");
                Console.WriteLine("3. Port 9600 is not blocked by firewall");
            }
            finally
            {
                udpClient?.Close();
            }
        }

        private static async Task ProcessTelemetryData(byte[] data)
        {
            try
            {
                // Parse the UDP packet (simplified - you'd need proper binary parsing)
                // For now, let's extract key values manually
                
                float speed = BitConverter.ToSingle(data, 16); // Speed at offset 16
                float gaspedal = BitConverter.ToSingle(data, 60); // Gas at offset 60
                float brakepedal = BitConverter.ToSingle(data, 64); // Brake at offset 64
                float steering = BitConverter.ToSingle(data, 72); // Steering at offset 72
                float rpm = BitConverter.ToSingle(data, 76); // RPM at offset 76
                int gear = BitConverter.ToInt32(data, 80); // Gear at offset 80
                int lapCount = BitConverter.ToInt32(data, 44); // Lap count at offset 44
                float lapTime = BitConverter.ToSingle(data, 36); // Lap time at offset 36
                
                // Extract car coordinates (you'll need to find the exact offsets)
                float carX = BitConverter.ToSingle(data, 200); // Approximate offset
                float carZ = BitConverter.ToSingle(data, 208); // Approximate offset
                
                float gForceX = BitConverter.ToSingle(data, 24); // Horizontal G-force
                float gForceZ = BitConverter.ToSingle(data, 32); // Frontal G-force

                // Create telemetry point
                var telemetryPoint = new TelemetryPoint
                {
                    time = lapTime / 1000f, // Convert to seconds
                    x = carX,
                    z = carZ,
                    speed = speed,
                    throttle = gaspedal,
                    brake = brakepedal,
                    steering = steering,
                    gForceX = gForceX,
                    gForceZ = gForceZ,
                    gear = gear,
                    rpm = rpm
                };

                // Add to current lap data
                currentLapData.Add(telemetryPoint);

                // Check if lap completed
                if (lapCount > lastLapCount && lastLapCount >= 0)
                {
                    Console.WriteLine($"🏁 Lap {lastLapCount + 1} completed!");
                    await SendLapToWebApp();
                    currentLapData.Clear();
                }

                lastLapCount = lapCount;

                // Print live data every 100 points to avoid spam
                if (currentLapData.Count % 100 == 0)
                {
                    Console.WriteLine($"Lap {lapCount + 1} | Speed: {speed:F1} km/h | Throttle: {gaspedal * 100:F0}% | Brake: {brakepedal * 100:F0}%");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing telemetry: {ex.Message}");
            }
        }

        private static async Task SendLapToWebApp()
        {
            if (currentLapData.Count == 0) return;

            try
            {
                // Calculate lap time from telemetry
                float lapTimeSeconds = currentLapData.Last().time - currentLapData.First().time;
                int minutes = (int)(lapTimeSeconds / 60);
                float seconds = lapTimeSeconds % 60;
                string lapTimeFormatted = $"{minutes}:{seconds:F3}";

                var lapData = new LapData
                {
                    lapTime = lapTimeFormatted,
                    car = "Unknown Car", // You can add car detection later
                    track = "Spa-Francorchamps",
                    conditions = "Dry",
                    telemetryPoints = currentLapData.ToList(),
                    sectorTimes = new SectorTimes
                    {
                        sector1 = lapTimeSeconds / 3, // Simplified - you'd calculate real sectors
                        sector2 = lapTimeSeconds / 3,
                        sector3 = lapTimeSeconds / 3
                    }
                };

                // Send to your Trail Break web app
                using var httpClient = new HttpClient();
                var json = JsonSerializer.Serialize(lapData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                
                var response = await httpClient.PostAsync($"{webAppUrl}/api/trpc/lap.create", content);
                
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"✅ Lap data sent successfully! Time: {lapTimeFormatted}");
                }
                else
                {
                    Console.WriteLine($"❌ Failed to send lap data: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error sending lap data: {ex.Message}");
            }
        }
    }
} 